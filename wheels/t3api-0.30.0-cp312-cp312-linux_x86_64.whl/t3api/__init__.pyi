"""The types of t3api's public surface (``__init__.py`` documents each function). The wheel's module is one compiled
extension with no docstrings and no annotations; this stub, shipped with ``py.typed``, is what a type checker reads."""
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from typing import Any, Literal, NotRequired, TypedDict

import numpy as np
import numpy.typing as npt

__all__ = ["TraceResult", "trace", "face_paths", "faces_svg", "faces_export", "faces_check", "planar_map",
           "planar_map_json", "read_planar_map", "paint_planar_map", "faces_svg_from_planar_map", "planar_map_paths",
           "planar_map_check", "strokes_svg_from_planar_map", "workers_of", "cache_dir", "normal_setting", "SETTING",
           "BUILD_ID", "VERSION", "HalfTable", "MinSweep", "Setting", "WSetting", "SettingInput", "AnySetting",
           "PaletteEntry", "PaletteDocument", "Palette", "Point", "Element", "Face", "FaceMap", "StrokeRef",
           "PlanarEdge", "PlanarFace", "StrokeEnd", "Stroke", "StrokeNode", "Dot", "NotStrokeReason", "NotStroke",
           "PlanarParts", "PlanarMap", "FacePath", "FacesCheck", "PlanarMapCheck", "Summary", "OnEvent"]

VERSION: str
BUILD_ID: str

# ----------------------------------------------------------------------------- the setting

class HalfTable(TypedDict):
    """Each kind's tube half-width in px, a number > 0, or None for a kind that is off (the line never is)."""
    line: float
    arc: float | None
    ellipse: float | None
    cubic: float | None

class MinSweep(TypedDict):
    """The least drawn sweep in degrees of an open circular and an open elliptical arc, each in [0, 360]."""
    arc: float
    ellipse: float

class Setting(TypedDict):
    """The canonical setting (``normal_setting``'s answer, the face map's and the planar map's ``setting``):
    ``min_sweep`` present only when a minimum is above 0; the stroke keys only with a line label, ``tiers`` only in
    the tiers mode and ``stroke_fallback`` only at ``face`` or ``best``."""
    half: HalfTable
    A1: float
    A2: float
    L: float
    min_sweep: NotRequired[MinSweep]
    line_labels: NotRequired[list[int]]
    width_mode: NotRequired[Literal["stroke", "colour", "tiers"]]
    tiers: NotRequired[int | Literal["auto"]]
    stroke_fallback: NotRequired[Literal["none", "face", "best"]]

class WSetting(TypedDict):
    """The setting a planar-map header up to t3api 0.26.0 holds: every kind at w / 2."""
    w: float
    A1: float
    A2: float
    L: float

class SettingInput(TypedDict, total=False):
    """Any setting ``normal_setting`` reads: each key merged over ``SETTING``; ``half`` or ``w``, never both."""
    half: HalfTable
    w: float
    A1: float
    A2: float
    L: float
    min_sweep: MinSweep
    line_labels: list[int]
    width_mode: Literal["stroke", "colour", "tiers"]
    tiers: int | Literal["auto"]
    stroke_fallback: Literal["none", "face", "best"]

AnySetting = Setting | WSetting | SettingInput

SETTING: Setting

# ----------------------------------------------------------------------------- the palette

class PaletteEntry(TypedDict):
    """One palette.json entry: the label ``index`` >= 0 and its colour ``hex`` ``#rrggbb``, with an optional
    ``name``. A caller's entry type may extend it with more keys (vinylgen's carries ``rgb``)."""
    index: int
    hex: str
    name: NotRequired[str | None]

class PaletteDocument(TypedDict):
    """palette.json's whole document; only its ``palette`` list is read."""
    palette: Sequence[PaletteEntry]

Palette = Sequence[PaletteEntry] | PaletteDocument

# ----------------------------------------------------------------------------- the face map and the planar map

Point = list[float]

class Element(TypedDict):
    """One drawn element of a ring (the face map's) or of an edge (the planar map's): ``seg`` the exact segment, a
    letter (``L``, ``E``, ``C``, ...) and its coordinates; ``node`` the Inkscape node type at its start."""
    kind: Literal["L", "A", "C", "border", "gap"]
    seg: list[str | float]
    node: Literal["c", "s", "z"]
    piece: int | None
    p0: Point
    p1: Point

class Face(TypedDict):
    """One face of the face map, in paint order: its rings of elements."""
    face: int
    label: int
    touches: bool
    rings: list[list[Element]]

class FaceMap(TypedDict):
    """The face map document (``TraceResult.face_map``)."""
    W: int
    H: int
    setting: Setting
    faces: list[Face]

class StrokeRef(TypedDict):
    """A face edge's place under a stroke: the stroke's index and the range [first, last] of its pieces the edge's
    pieces copy, byte for byte, in the stroke's direction."""
    stroke: int
    pieces: list[int]

class PlanarEdge(TypedDict):
    """One edge of the planar map, stored once: nodes ``a`` to ``b``, the face ids on its two sides; ``under`` when
    the edge lies under a stroke."""
    a: int
    b: int
    left: int | None
    right: int | None
    pieces: list[Element]
    under: NotRequired[StrokeRef]

class PlanarFace(TypedDict):
    """One face of the planar map, in paint order: its rings of signed edge references (``~k`` for edge k
    reversed)."""
    face: int
    label: int
    touches: bool
    rings: list[list[int]]

class StrokeEnd(TypedDict):
    """One end of an open stroke: ``free`` (a cap), ``node`` (on the stroke node ``node``) or ``split`` (where a
    width run or a fallback cut ends it)."""
    kind: Literal["free", "node", "split"]
    node: int | None

class Stroke(TypedDict):
    """One drawn stroke of a line label: its centreline ``pieces`` (as an edge's), drawn at ``width`` px, the width
    interval ``interval`` [lo, hi] and the averaged width ``mean``, its cap and join ``style``, its two ``ends`` (none
    for a ``cyclic`` stroke) and its ``flags``."""
    label: int
    pieces: list[Element]
    cyclic: bool
    width: float
    interval: list[float]
    mean: float
    style: Literal["round", "butt"]
    ends: list[StrokeEnd]
    flags: list[str]

class StrokeNode(TypedDict):
    """A node where three or more strokes meet: its point and degree."""
    pt: Point
    degree: int

class Dot(TypedDict):
    """A dot: a line-label region drawn as one round point, its centre ``c`` and its width."""
    label: int
    c: Point
    width: float

class NotStrokeReason(TypedDict):
    """The tube check's worst distances of a part the ``face`` fallback draws as a face: the border to the drawn
    outline and the drawn outline to the border, in px."""
    to_drawn: float
    to_border: float

class NotStroke(TypedDict):
    """A part of a line label the ``face`` fallback draws as a face, not a stroke: its pixel centres, its bounding
    box [x0, y0, x1, y1] and the check's worst distances."""
    label: int
    pixels: list[Point]
    bbox: list[float]
    reason: NotStrokeReason

class PlanarParts(TypedDict):
    """The trace's planar map without the file's header (``TraceResult.planar``); the stroke keys only when the
    trace has line labels."""
    nodes: list[Point]
    edges: list[PlanarEdge]
    faces: list[PlanarFace]
    strokes: NotRequired[list[Stroke]]
    stroke_nodes: NotRequired[list[StrokeNode]]
    dots: NotRequired[list[Dot]]
    not_stroke: NotRequired[list[NotStroke]]

class PlanarMap(TypedDict):
    """The planar-map file's document (``planar_map``, ``read_planar_map``). ``setting`` is the canonical form, or
    ``{w, A1, A2, L}`` in a header written up to 0.26.0. The stroke keys only when the trace has line labels."""
    format: Literal["t3-planar-map"]
    version: Literal[1]
    W: int
    H: int
    setting: Setting | WSetting
    build: str
    palette: list[list[int] | None] | None
    names: list[str | None] | None
    nodes: list[Point]
    edges: list[PlanarEdge]
    faces: list[PlanarFace]
    strokes: NotRequired[list[Stroke]]
    stroke_nodes: NotRequired[list[StrokeNode]]
    dots: NotRequired[list[Dot]]
    not_stroke: NotRequired[list[NotStroke]]

class FacePath(TypedDict):
    """One painted face as an even-odd SVG path and its Inkscape node types."""
    face: int
    label: int
    d: str
    nodetypes: str

class FacesCheck(TypedDict):
    """A faces file read back and painted against the face map (``differ`` 0 is the gate); ``first`` the first 20
    differing centres as (row, column, painted, read)."""
    differ: int
    first: list[tuple[int, int, int, int]]
    nodetypes_bad: int
    fill_bad: int
    paths: int

class PlanarMapCheck(TypedDict):
    """The planar-map file's invariants on the document alone (``violations`` 0 is the gate)."""
    nodes: int
    edges: int
    border_edges: int
    drawn_null_sides: int
    faces: int
    rings: int
    references: int
    pieces: int
    violations: int
    problems: list[str]

# ----------------------------------------------------------------------------- the trace

class Summary(TypedDict):
    """The trace's row summed up (``TraceResult.summary``)."""
    pieces: int
    kinds: dict[str, int]
    diff_px: int
    unpainted_px: int
    over_tube: int
    checks_count: int
    smooth: int
    corner: int
    termini: dict[str, int]
    open_arms: int
    faces: int
    faces_empty: int
    face_events_late: int
    workers: int
    gate: dict[str, Any]
    seconds: dict[str, float]

@dataclass(frozen=True)
class TraceResult:
    """One traced label array. ``row`` is t3's own row (``t3.row_of``), its fields the engine's."""
    face_map: FaceMap
    row: dict[str, Any]
    painted: npt.NDArray[np.int64]
    seconds: float
    warm_s: float
    workers: int = 1
    summary: Summary = ...
    planar: PlanarParts | None = None

# ``on_event(kind, payload)``: ``kind`` one of t3.trace's events, ``payload`` its JSON-serialisable dict.
OnEvent = Callable[[str, Any], None]

def cache_dir() -> str: ...
def workers_of(workers: int | None = None) -> int: ...
def normal_setting(setting: AnySetting | None = None) -> Setting: ...
def trace(labels: npt.NDArray[np.integer[Any]], setting: AnySetting | None = None, on_event: OnEvent | None = None,
          workers: int | None = None) -> TraceResult: ...
def face_paths(face_map: FaceMap) -> list[FacePath]: ...
def faces_svg(face_map: FaceMap, palette: Palette, stats: dict[str, Any] | None = None) -> str: ...
def faces_export(face_map_json: str, palette: Palette, stats: dict[str, Any] | None = None) -> str: ...
def faces_check(svg_text: str, face_map: FaceMap, palette: Palette | None = None) -> FacesCheck: ...
def planar_map(result: TraceResult, palette: Palette | None = None) -> PlanarMap: ...
def planar_map_json(pm: PlanarMap) -> str: ...
def read_planar_map(text: str) -> PlanarMap: ...
def paint_planar_map(pm: PlanarMap) -> npt.NDArray[np.int64]: ...
def faces_svg_from_planar_map(pm: PlanarMap, palette: Palette, stats: dict[str, Any] | None = None) -> str: ...
def planar_map_paths(pm: PlanarMap) -> list[FacePath]: ...
def planar_map_check(pm: PlanarMap | Mapping[str, Any]) -> PlanarMapCheck: ...
def strokes_svg_from_planar_map(pm: PlanarMap, palette: Palette) -> str: ...
